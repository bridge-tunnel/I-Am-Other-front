Rails.application.routes.draw do
  get 'users/index'

  # The priority is based upon order of creation: first created -> highest priority.
  # See how all your routes lay out with "rake routes".

  # You can have the root of your site routed with "root"
  root 'others#index'

  get 'typeahead' => 'identities#typeahead'
  get 'fetch' => 'others#fetch', :defaults => { :format => 'json' }
  
  resources :identities
  resources :users, :only => [:index, :destroy]
  devise_for :admins, :skip => :registerable, :path => 'admin', :path_names => {:sign_in => 'login', :sign_out => 'logout'}
  
  resources :others, :path => '/'
  

end
