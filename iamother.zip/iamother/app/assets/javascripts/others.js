var baseImage;
var resizeTimer;
var canvasReady;
var headerDiv;
var bodyDiv;
var footerDiv;
var formDiv;
var titleDiv;
var addBtn;
var zoomBtn;
var titleText;
var messageText;
var userImage;
var canvas;
var ctx;
var coloredImageCanvas;
var coloredImageCtx;
var coloredImageData;
var zoomedInCanvas;
var zoomedInCtx;
var zoomedInPixel;
var selectedPixel = null;
var zoomedPixelSize = 15;
var canvasScale = 1;
var canvasWidth;
var canvasHeight;

// The following variables are set by rails in views/others/index.html.erb
// var pixels_used
// var all_used

// turbolinks initialize
$(document).on('page:change', function() {
  $(":file").filestyle({
    icon: false,
    input: false,
    buttonText: "Add Photo",
    badge: false
  });

  var bloodhound = new Bloodhound({
    datumTokenizer: function(d) {
      return Bloodhound.tokenizers.whitespace(d.value);
    },
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    remote: {
      url: '/typeahead?query=%QUERY',
      wildcard: '%QUERY'
    },
    limit: 50
  });
  bloodhound.initialize();

  // initialize typeahead widget and hook it up to bloodhound engine
  $('#other_identity_name').typeahead({
    hint: true,
    highlight: true,
    minLength: 1
  }, {
    displayKey: 'name',
    source: bloodhound.ttAdapter()
  });

  // cache jQuery selectors
  headerDiv = $('#i-am-header');
  bodyDiv = $('#i-am-body');
  footerDiv = $('#i-am-footer');
  formDiv = $('#i-am-form');
  titleDiv = $('#i-am-title');
  titleText = $('#i-am-title-text');
  messageText = $('#i-am-message');
  userImage = $('#i-am-image');
  addBtn = $('#i-am-add');
  zoomBtn = $('#i-am-zoom');

  // INITIALIZING
  noPixelSelected();

  if (formDiv) formDiv.hide();
  titleDiv.show();

  if (!all_used) {
    showForm();
    titleDiv.hide();
  }

  zoomBtn.off("click");
  zoomBtn.click(function() {
    zoomOut();
  });
  zoomBtn.hide();

  zoomedInPixel = null;
  selectedPixel = null;

  loadBaseImage();

  // throttle resize events
  $(window).resize(function() {
    if (this.resizeTimer) clearTimeout(this.resizeTimer);
    this.resizeTimer = setTimeout(resizeCanvas, 500);
  });

  // show the modal splash screen
  if ($('#splashModal')) {
    $('#splashModal').modal();
  }

  updateShareLinks();
});

function loadBaseImage() {
  baseImage = new Image();
  baseImage.src = String(bodyDiv.data("image-src"));

  baseImage.onload = function() {
    //create canvas
    canvas = $('<canvas/>', {
      id: '#iam-canvas'
    }).prop({
      width: baseImage.width,
      height: baseImage.height
    });
    bodyDiv.append(canvas);
    ctx = canvas.get(0).getContext('2d');
    ctx.mozImageSmoothingEnabled = false;
    ctx.msImageSmoothingEnabled = false;
    ctx.imageSmoothingEnabled = false;

    canvasWidth = baseImage.width;
    canvasHeight = baseImage.height;
    //load the color overlay
    loadColoredImage();
  };
}

function loadColoredImage() {
  var coloredImage = new Image();
  coloredImage.src = String(bodyDiv.data("colored-image-src"));

  coloredImage.onload = function() {
    //create a temp canvas
    coloredImageCanvas = $('<canvas/>').prop({
      width: coloredImage.width,
      height: coloredImage.height
    });

    coloredImageCtx = coloredImageCanvas.get(0).getContext('2d');
    coloredImageCtx.mozImageSmoothingEnabled = false;
    coloredImageCtx.webkitImageSmoothingEnabled = false;
    coloredImageCtx.msImageSmoothingEnabled = false;
    coloredImageCtx.imageSmoothingEnabled = false;

    coloredImageCtx.drawImage(coloredImage, 0, 0);
    coloredImageData = coloredImageCtx.getImageData(0, 0, coloredImage.width, coloredImage.height);

    canvasReady = true;

    drawFullImage();

    //hide the placeholder
    bodyDiv.children('#iam-placeholder').hide();

    canvas.off("click");
    canvas.click(onCanvasClicked);

    selectedPixel = null;

    if (window.location.pathname.substring(1).length != 0) {
      loadPixel(window.location.pathname.substring(1));
    }

    resizeCanvas();
  };

}

function drawFullImage() {
  if (!canvasReady) return;

  ctx.clearRect(0, 0, canvasWidth, canvasHeight);

  //draw the base image
  ctx.drawImage(baseImage, 0, 0);

  // iterate over all pixels and draw if in our array of coloured pixels
  for (var i = 0, n = 0; i < coloredImageData.data.length; i += 4, n++) {
    if (pixels_used[n] == null) {
      coloredImageData.data[i + 3] = 0;
    } else {
      coloredImageData.data[i + 3] = 255;
    }
  }
  coloredImageCtx.putImageData(coloredImageData, 0, 0);
  ctx.drawImage(coloredImageCanvas.get(0), 0, 0);
}

function resizeCanvas() {
  if (!canvasReady) return;

  if (zoomedInPixel && selectedPixel) {
    var i = selectedPixel.i;
    zoomOut();
    loadPixel(i);
  } else if (zoomedInPixel) {
    var x = zoomedInPixel.x;
    var y = zoomedInPixel.y;
    zoomOut();
    zoomIn(x, y);
  }

  //resize the image to fit the page
  var width = $(window).width();

  var ratio = baseImage.width / baseImage.height;
  var scaledHeight = Math.floor((width / ratio));
  canvas.css({
    'height': scaledHeight + 'px',
    'width': width + 'px',
  });

  canvasScale = baseImage.width / width;
}

function loadPixel(i) {
  //given an index load and focus on that pixel
  zoomedInPixel = null;
  selectedPixel = {
    x: -1,
    y: -1
  };
  selectedPixel.i = i;

  //given the index work out the coords on the image and select there
  var x = i % baseImage.width;
  var y = Math.floor(i / baseImage.width);

  zoomIn(x, y);

  newPixelSelected();
}

function onCanvasClicked(e) {
  var canvasOffset = canvas.offset();
  var x = e.pageX - canvasOffset.left;
  var y = e.pageY - canvasOffset.top;

  //if zoomed out then we need to adjust for the canvas scale
  x = Math.round(x * canvasScale);
  y = Math.round(y * canvasScale);

  zoomIn(x, y);
}

function zoomIn(x, y) {
  if (zoomedInPixel == null) {
    var canvasOffset = canvas.offset();
    zoomedInPixel = {};
    zoomedInPixel.x = x;
    zoomedInPixel.y = y;

    // make a canvas if we don't have one
    if (zoomedInCanvas == null) {
      zoomedInCanvas = $('<canvas/>');
      zoomedInCtx = zoomedInCanvas.get(0).getContext('2d');
    }
    createZoomedInImage();
  } else {
    selectPixel(x, y);
  }
  zoomBtn.show();
}

function zoomOut(e) {
  if (zoomedInPixel != null) {
    zoomedInPixel = null;
    selectedPixel = null;

    //return canvas to normal and redraw
    canvas.prop({
      width: baseImage.width,
      height: baseImage.height
    });

    canvas.parent().off("scroll");

    drawFullImage();
  }
  zoomBtn.hide();
  noPixelSelected();
  if (!all_used) {
    showForm();
    titleDiv.hide();
  }

  updateShareLinks();
  window.history.pushState("object or string", "Title", "/");
}

function createZoomedInImage() {
  var across = Math.ceil(canvasWidth / zoomedPixelSize);
  var down = Math.ceil(canvasHeight / zoomedPixelSize);

  zoomedInPixel.minRow = Math.max(0, Math.floor(zoomedInPixel.y - down * 0.5));
  zoomedInPixel.minCol = Math.max(0, Math.floor(zoomedInPixel.x - across * 0.5));

  var maxRow = zoomedInPixel.minRow + down;
  var maxCol = zoomedInPixel.minCol + across;

  if (maxCol > canvasWidth) {
    maxCol = canvasWidth;
    zoomedInPixel.minCol = maxCol - across;
  }
  if (maxRow > canvasHeight) {
    maxRow = canvasHeight;
    zoomedInPixel.minRow = maxRow - down;
  }

  var canvasData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);

  //resize and clear out zoomed in canvas
  zoomedInCanvas.prop({
    width: canvasWidth,
    height: canvasHeight
  });
  zoomedInCtx.clearRect(0, 0, canvasWidth, canvasHeight);


  var x = 0;
  var y = 0;
  for (var c = zoomedInPixel.minCol; c <= maxCol; c++) {
    for (var r = zoomedInPixel.minRow; r <= maxRow; r++) {
      var red = canvasData.data[((canvasWidth * r) + c) * 4];
      var green = canvasData.data[((canvasWidth * r) + c) * 4 + 1];
      var blue = canvasData.data[((canvasWidth * r) + c) * 4 + 2];
      var col = rgbToHex(red, green, blue);
      //draw a rect on the new canvas
      zoomedInCtx.fillStyle = col;
      zoomedInCtx.fillRect(x, y, zoomedPixelSize, zoomedPixelSize);
      y += zoomedPixelSize;
    }
    y = 0;
    x += zoomedPixelSize;
  }

  drawZoomedInImage();
}

function drawZoomedInImage() {
  ctx.clearRect(0, 0, canvasWidth, canvasHeight);
  ctx.drawImage(zoomedInCanvas.get(0), 0, 0);

  if (selectedPixel !== null) {
    if (selectedPixel.x == -1 || selectedPixel.y == -1) {
      selectedPixel.x = (zoomedInPixel.x - zoomedInPixel.minCol) * zoomedPixelSize;
      selectedPixel.y = (zoomedInPixel.y - zoomedInPixel.minRow) * zoomedPixelSize;

    }
    //add selected pixel
    ctx.strokeStyle = 'red';
    ctx.strokeRect(selectedPixel.x, selectedPixel.y, zoomedPixelSize, zoomedPixelSize);
  }
}

function selectPixel(x, y) {
  selectedPixel = {
    x: x,
    y: y
  };

  //ground x & y to a multiple of the zoomedPixelSize
  selectedPixel.x -= selectedPixel.x % zoomedPixelSize;
  selectedPixel.y -= selectedPixel.y % zoomedPixelSize;

  var r = selectedPixel.y / zoomedPixelSize + zoomedInPixel.minRow;
  var c = selectedPixel.x / zoomedPixelSize + zoomedInPixel.minCol;

  selectedPixel.i = ((canvasWidth * r) + c);

  //no longer allow the user to select their own pixel
  if (pixels_used[selectedPixel.i] == null) {
    selectedPixel = null;
    return;
  }

  newPixelSelected();

  drawZoomedInImage();
}

function noPixelSelected() {
  $('#other_pixel').val("");
  titleText.text("Other");
  messageText.text("");
  userImage.hide();
  $(document).prop('title', "I AM OTHER");
}

function newPixelSelected() {
  if (pixels_used[selectedPixel.i] != null) {
    if (formDiv) formDiv.hide();
    titleDiv.hide();

    $.get('/fetch', {
      id: pixels_used[selectedPixel.i]
    }, function(data) {
      titleDiv.show();
      titleText.text(data.n);
      if (data.m != null)
        messageText.text(data.m);
      else
        messageText.text("");

      if (data.i != null) {
        userImage.show();
        userImage.attr("src", data.i);
      } else {
        userImage.hide();
      }

      $(document).prop('title', "I AM " + data.n);
    });
  } else {
    $(document).prop('title', "I AM OTHER");
    showForm();
    titleDiv.hide();
  }

  updateURL();
}

function showForm() {
  if (formDiv) formDiv.show();
  if (selectedPixel != null)
    $('#other_pixel').val(selectedPixel.i);
  else
    $('#other_pixel').val("");
}

function updateURL() {
  window.history.pushState("object or string", "Title", String(selectedPixel.i));
  updateShareLinks();
}

function updateShareLinks() {
  $('#share-fb').attr('href', "http://www.facebook.com/sharer/sharer.php?u=" + window.location);
  $('#share-tw').attr('href', "http://twitter.com/intent/tweet?url=" + window.location);
  //$('#share-in').attr('href', window.location);
  $('#share-em').attr('href', "mailto:?subject=I AM OTHER&body=This story is powerful: " + window.location);
}

function rgbToHex(r, g, b) {
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}
