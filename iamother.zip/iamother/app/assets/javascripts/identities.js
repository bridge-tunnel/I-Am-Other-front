
$(document).on('page:change', function() { 
  /* Activating Best In Place */
  jQuery(".best_in_place").best_in_place();
  
  $('.best_in_place').bind("ajax:success", function () {$(this).closest('tr').effect('highlight'); });
});