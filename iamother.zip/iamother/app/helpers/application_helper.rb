module ApplicationHelper
  def nav_bar_link(target_page, link_name, target_controller)
    if target_controller == controller_name || current_page?(target_page)
      content_tag(:li, link_to(link_name, target_page), :class => 'active' ) 
    else 
      content_tag(:li, link_to(link_name, target_page) )
    end
  end
end
