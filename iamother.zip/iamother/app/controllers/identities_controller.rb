class IdentitiesController < ApplicationController
  
  respond_to :html, :json
  
  before_filter :find_identity, only: [:update,:destroy]
    
  before_action :authenticate_admin!, except: [:typeahead]
  
  def index
    @identity = Identity.new
    @identities = Identity.includes(:others).order(:name).paginate(:page => params[:page])
  end
  
  def create   
    if params[:identity].blank? || params[:identity][:name].blank?
      return redirect_to identities_path, notice: "Name cannot be blank."
    end
     
    identity = Identity.find_or_create_by(:name => params[:identity][:name].upcase)
    if identity.id.nil?
      return redirect_to identities_path, notice: "Error: " + identity.errors.full_messages.join(",")
    end
    
    redirect_to identities_path, notice: "New Identity Added."
  end
  
  def update    
    respond_to do |format|
      if @identity.update_attributes(update_permitted_params)
        format.html { redirect_to identities_path, :notice => 'Identity was successfully updated.' }
        format.json { respond_with_bip(@identity) }
      else
        format.html { redirect_to identities_path, notice: "Error: " + identity.errors.full_messages.join(",") }
        format.json { respond_with_bip(@identity) }
      end
    end  
  end

  def destroy
    @identity.destroy
    #render :json => true
    redirect_to identities_path, notice: "Identity Deleted"
  end
  
  def typeahead
    
    query = params[:query].upcase unless params[:query].blank?
    
    if query.blank?
      results = Identity.where(nil)
    else
      puts "Query: " + query
      results = Identity.where('name ilike ?', "%#{query}%")
    end
    
    render json: results
  end
  
  protected

    def update_permitted_params
      params.require(:identity).permit(:name)
    end
    
    def find_identity
      @identity = Identity.find_by(:id => params[:id])
      if @identity.blank?
        redirect_to identities_path, notice: 'Identity could not be found.'
        false
      end
    end
    
end
