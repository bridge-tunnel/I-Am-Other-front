class OthersController < ApplicationController
  
  before_action :authenticate_admin!, only: [:destroy]
  #the index of the other's controller is our main page
  
  def index
    @showSplash = notice.blank? && alert.blank?
    prep_pixels
  end
  
  def show
    @showSplash = false
    @other = Other.find_by(:pixel => params[:id]) unless params[:id].blank?
    #@pixel = params[:id] 
    
    if @other.blank?
     return redirect_to root_path
    end
    
    prep_pixels
    render "index"
  end
  
  def fetch
    other = Other.find_by(:pixel => params[:id]) 
    
    if other.blank? 
      render :status => :not_found, :json => {:n => "", :m => ""}
    else
      render :status => :ok, :json => { :n => other.name, :m => other.story, :i => other.image.url }
    end
  end
  
  def create
    if params[:other].blank? || params[:other][:identity_name].blank?
      return redirect_to others_path, :flash => { :alert => "Sorry but you must specify an OTHER, if you can't find one just add it." }
    end
    
    @identity = Identity.find_or_create_by(:name => params[:other][:identity_name].upcase)
    if @identity.id.nil?
      return redirect_to others_path, notice: "Sorry but " + @identity.errors.full_messages.join(" and ") + ". Please try again."
    end
    
    @other = Other.new(permitted_params)
    
    @other.identity = @identity
    
    # TODO.could add a session to store a just created option and so not show the link again if they just added
    
    if @other.save
      redirect_to other_path(:id => @other.pixel), notice: "THANKS! You are one in a million! Now please help us reach ONE MILLION PEOPLE FOR CHANGE! You have entered for a chance of being ONE of 160 people who will be invited to
Memphis, Tennassee in 2018 for a special photo shoot where we will re-stage the Ernest
Withers image as a homage to its power in defining the importance of the worth of each
and every man. We believe this photo is as relevant today as in the 1960's where these
courageous men took the stand to affirm their unique and equal position as members of
the human race. Today, there are still communities of people fighting for equality and
this photo can be a tribute where we celebrate that we are all ONE, All MEN, All HUMAN,
all SPECIAL and all VERY UNIQUE. On the 50th anniversary of the photo, we will invite
participants to re-stage this photo with a world-renowned photographer"
    else
      redirect_to others_path, notice: "Sorry but " + @other.errors.full_messages.join(" and ") + ". Please try again."
    end
    
  end
  
  def destroy
    @other = Other.find_by(:pixel => params[:id]) unless params[:id].blank?
    
    @other.destroy
    #render :json => true
    redirect_to others_path, notice: "Entry Deleted"
  end
  
protected
  def prep_pixels
    pixels = Other.order("pixel ASC").pluck(:pixel)
    
    @another = Other.new
    @identities = Identity.order("name ASC").pluck(:name)
    
    max = ENV["MAX_PIXELS"].to_i
    
    @pixels_used = Array.new(max, nil)
     
    pixels.each do | pixel |
       puts "pixel found at " + pixel.to_s;
       @pixels_used[pixel] = pixel;
    end
  
    @all_used = pixels.count == max
    
  end
  def permitted_params
    params.require(:other).permit(:story, :pixel, :image, :email)
  end
  
end
