class UsersController < ApplicationController
    
  before_action :authenticate_admin!
  
  def index
    @users = Other.paginate(:page => params[:page])
    respond_to do |format|
      format.html
      format.csv { send_data @users.to_csv, filename: "users-#{Date.today}.csv" }
    end
    
  end
  
end
