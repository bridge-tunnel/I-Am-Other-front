
require 'file_size_validator' 

class Other < ActiveRecord::Base
  
  mount_uploader :image, ImageUploader
  
  belongs_to :identity
  
  attr_accessor :identity_name, :image_cache
  
  validates :story, :presence => true, :length => { :maximum => ENV["MESSAGE_MAX_LENGTH"].to_i }
  
  validates :pixel, :uniqueness => { :story => "already used." }
  
  validates :email, :presence => true, :uniqueness => { :story => "already used." }
  validates_format_of :email, :with => /\b[A-Z0-9._%a-z\-]+@(?:[A-Z0-9a-z\-]+\.)+[A-Za-z]{2,6}\z/
  
  validates :image, :presence => true, :file_size => { :maximum => 0.5.megabytes.to_i }
  
  before_save :generate_pixel
  
  def name
    identity.name
  end
  
  def to_param  # overridden
    pixel
  end
  
  def self.to_csv
    attributes = %w{id email pixel name story}

    CSV.generate(headers: true) do |csv|
      csv << attributes

      all.each do |user|
        csv << attributes.map{ |attr| user.send(attr) }
      end
    end
  end
  
  protected
  
  def generate_pixel
    max = ENV["MAX_PIXELS"].to_i
    return unless pixel.blank? || pixel > max
    
    available_pixels = (1..max).to_a - Other.pluck(:pixel)
    
    if available_pixels.length == 0 
      self.pixel = nil
    else
      self.pixel = available_pixels[rand(available_pixels.length)]
    end
  end
  
end
