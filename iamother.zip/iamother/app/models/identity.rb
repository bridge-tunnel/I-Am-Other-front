class Identity < ActiveRecord::Base
  self.per_page = 10
  
  has_many :others, dependent: :destroy
  
  validates :name, :presence => true,  :length => { :minimum => ENV["IDENTITY_MIN_LENGTH"].to_i, :maximum => ENV["IDENTITY_MAX_LENGTH"].to_i }
  validates :name, :uniqueness => { :message => "Name already used." }
  
  before_validation :upcase_name
  
  def as_json(options={})
    super(:only => [:name])
  end
  protected
  
  def upcase_name
    self.name = name.upcase unless name.blank?
  end
end
