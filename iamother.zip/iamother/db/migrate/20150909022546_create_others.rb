class CreateOthers < ActiveRecord::Migration
  def change
    create_table :others do |t|
      t.integer :pixel
      t.string :story
      t.string :image
      t.string :email
      
      t.belongs_to :identity, index: true

      t.timestamps null: false
    end
  end
end
