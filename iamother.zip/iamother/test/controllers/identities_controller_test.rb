require 'test_helper'

class IdentitiesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
