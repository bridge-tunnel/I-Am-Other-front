require 'test_helper'

class OthersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
