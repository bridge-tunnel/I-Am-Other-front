# I AM OTHER

### Uses
* Rails
* Postgres
* Bootstrap
* jQuery
* Canvas
* SASS
* Figaro (loads env-vars from config/application.yml, see application_example.yml for requirements)
* Carrierwave + rmagick
* Sendgrid

Bulk of the 'good stuff' is the JavaScript in app/assets/javascript/others.js.
CSS is in app/assets/stylesheets/application.scss.

### Structure
There are three DB Models.
* An Identity is what someone can say they are eg. 'Person'
* An Other is a submission by a user: email, story, pixel id etc
  * A Identity has_many Others and an Other belongs_to an Identity
* An Admin can edit/delete Others and Identities

The db/seeds.rb creates an Admin User and a default Identity called 'OTHER'.

### Run
The following should get you up and running:
* bundle install
* rake db:create
* rake db:migrate
* rake db:seed
* rails s

### Apologies
Sorry for the brevity.
